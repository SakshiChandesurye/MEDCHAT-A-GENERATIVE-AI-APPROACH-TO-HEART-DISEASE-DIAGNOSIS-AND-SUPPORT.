import os
import chromadb
import google.generativeai as genai
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.neighbors import NearestNeighbors
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from openai import OpenAI
import re
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import json
import uuid

load_dotenv()

genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# Path to the embeddings folder
EMBEDDINGS_FOLDER = "embeddings"

# Initialize the OpenAI Client with RunPod API Key and Endpoint URL
openai_client = OpenAI(
  api_key=os.environ.get("RUNPOD_API_KEY"),
  base_url=f"https://api.runpod.ai/v2/g1p4in38ovxbf7/openai/v1",
)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)  # For session management
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///heart_disease_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db = SQLAlchemy(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# User model
class User(UserMixin, db.Model):
  id = db.Column(db.Integer, primary_key=True)
  name = db.Column(db.String(100), nullable=False)
  age = db.Column(db.Integer, nullable=False)
  gender = db.Column(db.String(10), nullable=False)
  username = db.Column(db.String(50), unique=True, nullable=False)
  password_hash = db.Column(db.String(128), nullable=False)
  created_at = db.Column(db.DateTime, default=datetime.utcnow)
  
  # Relationships
  ai_chat_sessions = db.relationship('AIChatSession', backref='user', lazy=True, cascade="all, delete-orphan")
  rag_chat_sessions = db.relationship('RAGChatSession', backref='user', lazy=True, cascade="all, delete-orphan")

  def set_password(self, password):
      self.password_hash = generate_password_hash(password)

  def check_password(self, password):
      return check_password_hash(self.password_hash, password)

# AI Chat Session model
class AIChatSession(db.Model):
  id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
  title = db.Column(db.String(100), nullable=False, default="New Chat")
  created_at = db.Column(db.DateTime, default=datetime.utcnow)
  updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
  user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
  
  # Relationships
  messages = db.relationship('AIChatMessage', backref='session', lazy=True, cascade="all, delete-orphan", order_by="AIChatMessage.timestamp")
  
  def get_first_user_message(self):
      for message in self.messages:
          if message.role == 'user':
              return message.content[:30] + "..." if len(message.content) > 30 else message.content
      return "New Chat"
  
  def update_title(self):
      first_message = self.get_first_user_message()
      if first_message != "New Chat":
          self.title = first_message
          db.session.commit()

# AI Chat Message model
class AIChatMessage(db.Model):
  id = db.Column(db.Integer, primary_key=True)
  role = db.Column(db.String(10), nullable=False)  # 'user' or 'assistant'
  content = db.Column(db.Text, nullable=False)
  timestamp = db.Column(db.DateTime, default=datetime.utcnow)
  session_id = db.Column(db.String(36), db.ForeignKey('ai_chat_session.id'), nullable=False)

# RAG Chat Session model
class RAGChatSession(db.Model):
  id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
  title = db.Column(db.String(100), nullable=False, default="New Chat")
  created_at = db.Column(db.DateTime, default=datetime.utcnow)
  updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
  user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
  
  # Relationships
  messages = db.relationship('RAGChatMessage', backref='session', lazy=True, cascade="all, delete-orphan", order_by="RAGChatMessage.timestamp")
  
  def get_first_user_message(self):
      for message in self.messages:
          if message.role == 'user':
              return message.content[:30] + "..." if len(message.content) > 30 else message.content
      return "New Chat"
  
  def update_title(self):
      first_message = self.get_first_user_message()
      if first_message != "New Chat":
          self.title = first_message
          db.session.commit()

# RAG Chat Message model
class RAGChatMessage(db.Model):
  id = db.Column(db.Integer, primary_key=True)
  role = db.Column(db.String(10), nullable=False)  # 'user' or 'assistant'
  content = db.Column(db.Text, nullable=False)
  sources = db.Column(db.Text, nullable=True)  # JSON string of sources
  timestamp = db.Column(db.DateTime, default=datetime.utcnow)
  session_id = db.Column(db.String(36), db.ForeignKey('rag_chat_session.id'), nullable=False)
  
  def get_sources(self):
      if self.sources:
          return json.loads(self.sources)
      return []
  
  def set_sources(self, sources):
      self.sources = json.dumps(sources)

@login_manager.user_loader
def load_user(user_id):
  return User.query.get(int(user_id))

class HeartDiseaseRAGSystem:
  def __init__(self):
      # Using the same embedding model used for creating the database
      self.embedding_model = SentenceTransformer('pritamdeka/S-PubMedBert-MS-MARCO')
      
      # Connect to the persistent ChromaDB
      try:
          self.chroma_client = chromadb.PersistentClient(path=EMBEDDINGS_FOLDER)
          self.collection = self.chroma_client.get_collection("heart_disease_docs")
          # Get collection count for display
          self.doc_count = self.collection.count()
          
          # Initialize KNN model for better retrieval
          self.initialize_knn()
      except Exception as e:
          raise Exception(f"Failed to connect to ChromaDB: {str(e)}\nMake sure the 'embeddings' folder contains a valid ChromaDB database.")
  
  def initialize_knn(self):
      # Get all embeddings from the collection
      all_embeddings = self.collection.get(
          include=["embeddings", "documents", "metadatas"],
          limit=self.doc_count
      )
      
      # Convert embeddings to numpy array for KNN
      self.embeddings_array = np.array(all_embeddings["embeddings"])
      self.documents = all_embeddings["documents"]
      self.metadatas = all_embeddings["metadatas"]
      
      # Initialize KNN model
      self.knn_model = NearestNeighbors(
          n_neighbors=7,  # Increased from 5 to get more context
          algorithm='auto',
          metric='cosine'
      )
      self.knn_model.fit(self.embeddings_array)
  
  def retrieve_relevant_docs(self, query, top_k=7):
      # Generate embedding for the query
      query_embedding = self.embedding_model.encode(query).tolist()
      
      # Use KNN to find nearest neighbors
      distances, indices = self.knn_model.kneighbors(
          [query_embedding], 
          n_neighbors=min(top_k, self.doc_count)
      )
      
      # Get the documents from the indices
      retrieved_docs = [self.documents[idx] for idx in indices[0]]
      retrieved_metadata = [self.metadatas[idx] for idx in indices[0]]
      
      # Check if the retrieved documents are relevant
      # Calculate average distance to determine relevance
      avg_distance = np.mean(distances[0])
      
      # If average distance is too high, consider the documents not relevant
      if avg_distance > 0.7:  # Threshold for relevance
          return [], []
      
      # Handle case where no documents are found
      if not retrieved_docs:
          return [], []
      
      return retrieved_docs, retrieved_metadata
  
  def generate_response(self, query):
      # Retrieve relevant documents
      context_docs, metadata = self.retrieve_relevant_docs(query)
      
      # If no relevant documents found, return a message indicating lack of information
      if not context_docs:
          return "I don't have enough information in my knowledge base to answer this question accurately.", []
      
      # Join the documents into a single context
      context = "\n\n".join(context_docs)
      
      # Generate response using Gemini
      model = genai.GenerativeModel(
          'gemini-2.0-flash',
          generation_config={
              "max_output_tokens": 2048,
              "temperature": 0.1,  # Reduced temperature for more factual responses
              "top_p": 0.95,
              "top_k": 40
          }
      )
      
      prompt = f"""You are a medical chatbot specializing in heart disease. Your ONLY knowledge comes from the provided context information.

      Context information from medical documents:
      {context}
      
      User Query: {query}
      
      Instructions:
      1. ONLY use information explicitly stated in the provided context. DO NOT use any external knowledge or information not present in the context.
      2. If the information in the context is not sufficient to answer the query, say "I don't have enough information in my knowledge base to answer this question accurately."
      3. DO NOT make up or infer information that is not explicitly stated in the context.
      4. DO NOT mention any source documents, PDF names, or page numbers in your response.
      5. Format your response in a clear, organized manner with headings if appropriate.
      6. Use medical terminology but explain it in layman's terms when necessary.
      7. If you're unsure about any part of the answer, acknowledge the limitations of the provided context.
      8. DO NOT begin your response with any disclaimer about medical advice.
      9. If the user asks about doctors or specialists, suggest they visit the Top Doctors page to find cardiologists in their region.
      """
      
      response = model.generate_content(prompt)
      return response.text, context_docs

# Initialize RAG system
rag_system = None
try:
  rag_system = HeartDiseaseRAGSystem()
  print(f"Successfully loaded heart disease knowledge base with {rag_system.doc_count} document chunks.")
except Exception as e:
  print(f"Error initializing RAG system: {str(e)}")

# Heart-related keywords for filtering AI chat responses
HEART_KEYWORDS = [
  'heart', 'cardiac', 'cardiovascular', 'cardio', 'chest pain', 'arrhythmia', 'palpitation',
  'blood pressure', 'hypertension', 'cholesterol', 'angina', 'myocardial', 'infarction',
  'coronary', 'arteries', 'veins', 'valve', 'ecg', 'ekg', 'electrocardiogram', 'stroke',
  'circulation', 'pulse', 'heartbeat', 'tachycardia', 'bradycardia', 'fibrillation',
  'atherosclerosis', 'stent', 'bypass', 'angioplasty', 'lipids', 'statins', 'beta blocker',
  'ace inhibitor', 'diuretic', 'anticoagulant', 'aspirin', 'clopidogrel', 'warfarin',
  'pacemaker', 'defibrillator', 'cardiologist', 'cardiomyopathy', 'heart failure',
  'heart attack', 'heart disease', 'heart health', 'cardiovascular disease'
]

def is_heart_related(query):
  """Check if the query is related to heart health"""
  query = query.lower()
  return any(keyword in query for keyword in HEART_KEYWORDS)

@app.route('/')
def home():
  if current_user.is_authenticated:
      return redirect(url_for('dashboard'))
  return redirect(url_for('login'))

# Add a new dashboard route
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

# Update the index route to be /rag_chat instead of /dashboard
@app.route('/rag_chat')
@login_required
def index():
  # Get the session ID from the query parameter, or use the most recent session
  session_id = request.args.get('session_id')
  
  # Get all chat sessions for the current user
  chat_sessions = RAGChatSession.query.filter_by(user_id=current_user.id).order_by(RAGChatSession.updated_at.desc()).all()
  
  # If no sessions exist, create a new one
  if not chat_sessions:
      new_session = RAGChatSession(user_id=current_user.id)
      db.session.add(new_session)
      db.session.commit()
      chat_sessions = [new_session]
      session_id = new_session.id
  
  # If session_id is not provided or doesn't exist, use the most recent session
  if not session_id or not RAGChatSession.query.get(session_id):
      session_id = chat_sessions[0].id
  
  # Get the current chat session
  current_session = RAGChatSession.query.get(session_id)
  
  # Get messages for the current session
  messages = current_session.messages
  
  return render_template('index.html', 
                         messages=messages, 
                         chat_sessions=chat_sessions, 
                         current_session=current_session)

@app.route('/aichat')
@login_required
def aichat():
    # Get the session ID from the query parameter, or use the most recent session
    session_id = request.args.get('session_id')
    
    # Get all chat sessions for the current user
    chat_sessions = AIChatSession.query.filter_by(user_id=current_user.id).order_by(AIChatSession.updated_at.desc()).all()
    
    # If no sessions exist, create a new one
    if not chat_sessions:
        new_session = AIChatSession(user_id=current_user.id)
        db.session.add(new_session)
        db.session.commit()
        chat_sessions = [new_session]
        session_id = new_session.id
    
    # If session_id is not provided or doesn't exist, use the most recent session
    if not session_id or not AIChatSession.query.get(session_id):
        session_id = chat_sessions[0].id
    
    # Get the current chat session
    current_session = AIChatSession.query.get(session_id)
    
    # Get messages for the current session
    messages = current_session.messages
    
    return render_template('aichat.html', 
                         messages=messages, 
                         chat_sessions=chat_sessions, 
                         current_session=current_session)

@app.route('/top_doctors')
@login_required
def top_doctors():
    return render_template('top_doctors.html')

@app.route('/aichat/new', methods=['POST'])
@login_required
def new_aichat():
    # Create a new chat session
    new_session = AIChatSession(user_id=current_user.id)
    db.session.add(new_session)
    db.session.commit()
    
    return redirect(url_for('aichat', session_id=new_session.id))

@app.route('/aichat/ask', methods=['POST'])
@login_required
def aichat_ask():
    data = request.json
    query = data.get('query', '')
    session_id = data.get('session_id', '')
    
    if not query:
        return jsonify({
            'success': False,
            'message': 'Please provide a query.'
        })
    
    # Get the current chat session
    current_session = AIChatSession.query.get(session_id)
    if not current_session or current_session.user_id != current_user.id:
        return jsonify({
            'success': False,
            'message': 'Invalid chat session.'
        })
    
    try:
        # Add user message to the session
        user_message = AIChatMessage(
            role='user',
            content=query,
            session_id=session_id
        )
        db.session.add(user_message)
        db.session.commit()
        
        # Update the session title if it's the first message
        if len(current_session.messages) == 1:  # Only the message we just added
            current_session.update_title()
        
        # Update the session's updated_at timestamp
        current_session.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Generate response using OpenAI
        try:
            response = openai_client.chat.completions.create(
                model="Sakshi0403/Llama-3.2-3B-Instruct_finetune_model",
                messages=[
                    {"role": "system", "content": "You are a medical assistant specialized in heart disease. Provide accurate, evidence-based information about heart health, cardiovascular diseases, symptoms, treatments, and prevention strategies. Keep your responses focused on heart-related topics. If asked about non-heart-related medical topics, politely redirect to heart health. Do not provide personal medical advice or diagnosis. If the user asks about doctors or specialists, suggest they visit the Top Doctors page to find cardiologists in their region."},
                    {"role": "user", "content": query}
                ],
                temperature=0.7,
                
            )
            ai_response = response.choices[0].message.content
        except Exception as e:
            # Fallback response if OpenAI API fails
            ai_response = "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again later."
            print(f"OpenAI API error: {str(e)}")
        
        # Add assistant response to the session
        assistant_message = AIChatMessage(
            role='assistant',
            content=ai_response,
            session_id=session_id
        )
        db.session.add(assistant_message)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'response': ai_response
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error generating response: {str(e)}'
        })

@app.route('/aichat/delete/<session_id>', methods=['POST'])
@login_required
def delete_chat_session(session_id):
    # Get the chat session
    session = AIChatSession.query.get(session_id)
    
    # Check if the session exists and belongs to the current user
    if not session or session.user_id != current_user.id:
        flash('Invalid chat session.')
        return redirect(url_for('aichat'))
    
    # Delete the session
    db.session.delete(session)
    db.session.commit()
    
    # Redirect to the most recent chat session or create a new one if none exist
    most_recent = AIChatSession.query.filter_by(user_id=current_user.id).order_by(AIChatSession.updated_at.desc()).first()
    if most_recent:
        return redirect(url_for('aichat', session_id=most_recent.id))
    else:
        # Create a new session
        new_session = AIChatSession(user_id=current_user.id)
        db.session.add(new_session)
        db.session.commit()
        return redirect(url_for('aichat', session_id=new_session.id))

@app.route('/aichat/reset/<session_id>', methods=['POST'])
@login_required
def reset_chat_session(session_id):
    # Get the chat session
    session = AIChatSession.query.get(session_id)
    
    # Check if the session exists and belongs to the current user
    if not session or session.user_id != current_user.id:
        flash('Invalid chat session.')
        return redirect(url_for('aichat'))
    
    # Delete all messages in the session
    AIChatMessage.query.filter_by(session_id=session_id).delete()
    
    # Reset the session title
    session.title = "New Chat"
    db.session.commit()
    
    return redirect(url_for('aichat', session_id=session_id))

# Update the new_rag_chat route to redirect to rag_chat
@app.route('/rag_chat/new', methods=['POST'])
@login_required
def new_rag_chat():
  # Create a new chat session
  new_session = RAGChatSession(user_id=current_user.id)
  db.session.add(new_session)
  db.session.commit()
  
  return redirect(url_for('index', session_id=new_session.id))

@app.route('/ask', methods=['POST'])
@login_required
def ask():
  if not rag_system:
      return jsonify({
          'success': False,
          'message': 'The system is not properly initialized. Please check the server logs.'
      })
  
  data = request.json
  query = data.get('query', '')
  session_id = data.get('session_id', '')
  
  if not query:
      return jsonify({
          'success': False,
          'message': 'Please provide a query.'
      })
  
  # Get the current chat session
  current_session = RAGChatSession.query.get(session_id)
  if not current_session or current_session.user_id != current_user.id:
      return jsonify({
          'success': False,
          'message': 'Invalid chat session.'
      })
  
  try:
      # Add user message to the session
      user_message = RAGChatMessage(
          role='user',
          content=query,
          session_id=session_id
      )
      db.session.add(user_message)
      db.session.commit()
      
      # Update the session title if it's the first message
      if len(current_session.messages) == 1:  # Only the message we just added
          current_session.update_title()
      
      # Update the session's updated_at timestamp
      current_session.updated_at = datetime.utcnow()
      db.session.commit()
      
      # Generate response
      response, sources = rag_system.generate_response(query)
      
      # Add assistant response to the session
      assistant_message = RAGChatMessage(
          role='assistant',
          content=response,
          session_id=session_id
      )
      
      # Only set sources if we have a valid response (not the "I don't have enough information" message)
      if not response.startswith("I don't have enough information"):
          assistant_message.set_sources(sources)
      else:
          # Set empty sources for responses indicating lack of information
          assistant_message.set_sources([])
      
      db.session.add(assistant_message)
      db.session.commit()
      
      return jsonify({
          'success': True,
          'response': response,
          'sources': sources if not response.startswith("I don't have enough information") else []
      })
  except Exception as e:
      return jsonify({
          'success': False,
          'message': f'Error generating response: {str(e)}'
      })

# Update the delete_rag_chat_session route to redirect to rag_chat
@app.route('/rag_chat/delete/<session_id>', methods=['POST'])
@login_required
def delete_rag_chat_session(session_id):
  # Get the chat session
  session = RAGChatSession.query.get(session_id)
  
  # Check if the session exists and belongs to the current user
  if not session or session.user_id != current_user.id:
      flash('Invalid chat session.')
      return redirect(url_for('index'))
  
  # Delete the session
  db.session.delete(session)
  db.session.commit()
  
  # Redirect to the most recent chat session or create a new one if none exist
  most_recent = RAGChatSession.query.filter_by(user_id=current_user.id).order_by(RAGChatSession.updated_at.desc()).first()
  if most_recent:
      return redirect(url_for('index', session_id=most_recent.id))
  else:
      # Create a new session
      new_session = RAGChatSession(user_id=current_user.id)
      db.session.add(new_session)
      db.session.commit()
      return redirect(url_for('index', session_id=new_session.id))

# Update the reset_rag_chat_session route to redirect to rag_chat
@app.route('/rag_chat/reset/<session_id>', methods=['POST'])
@login_required
def reset_rag_chat_session(session_id):
  # Get the chat session
  session = RAGChatSession.query.get(session_id)
  
  # Check if the session exists and belongs to the current user
  if not session or session.user_id != current_user.id:
      flash('Invalid chat session.')
      return redirect(url_for('index'))
  
  # Delete all messages in the session
  RAGChatMessage.query.filter_by(session_id=session_id).delete()
  
  # Reset the session title
  session.title = "New Chat"
  db.session.commit()
  
  return redirect(url_for('index', session_id=session_id))

# Add the about route
@app.route('/about')
@login_required
def about():
    return render_template('about.html')

# Add the update_profile route
@app.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    # Get form data
    name = request.form.get('name')
    age = request.form.get('age')
    gender = request.form.get('gender')
    username = request.form.get('username')
    
    # Validate inputs
    if not all([name, age, gender, username]):
        flash('All fields are required', 'error')
        return redirect(url_for('profile'))
    
    # Check if username already exists (if changed)
    if username != current_user.username:
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists', 'error')
            return redirect(url_for('profile'))
    
    # Update user data
    current_user.name = name
    current_user.age = age
    current_user.gender = gender
    current_user.username = username
    
    db.session.commit()
    
    flash('Profile updated successfully!', 'success')
    return redirect(url_for('profile'))

# Add forgot password route
@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        
        # Check if user exists
        user = User.query.filter_by(username=username).first()
        if not user:
            flash('No account found with that username', 'error')
            return render_template('forgot_password.html')
        
        # Redirect to reset password page
        return redirect(url_for('reset_password', username=username))
    
    return render_template('forgot_password.html')

# Add reset password route
@app.route('/reset-password/<username>', methods=['GET', 'POST'])
def reset_password(username):
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    # Check if user exists
    user = User.query.filter_by(username=username).first()
    if not user:
        flash('Invalid username', 'error')
        return redirect(url_for('forgot_password'))
    
    if request.method == 'POST':
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate passwords
        if not new_password or not confirm_password:
            flash('Please enter both passwords', 'error')
            return render_template('reset_password.html', username=username)
        
        if new_password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('reset_password.html', username=username)
        
        # Update password
        user.set_password(new_password)
        db.session.commit()
        
        flash('Password has been reset successfully! You can now login with your new password.', 'success')
        return redirect(url_for('login'))
    
    return render_template('reset_password.html', username=username)

# Update the login route to redirect to dashboard
@app.route('/login', methods=['GET', 'POST'])
def login():
  if current_user.is_authenticated:
      return redirect(url_for('dashboard'))
  
  if request.method == 'POST':
      username = request.form.get('username')
      password = request.form.get('password')
      
      user = User.query.filter_by(username=username).first()
      
      if user and user.check_password(password):
          login_user(user)
          return redirect(url_for('dashboard'))
      else:
          flash('Invalid username or password', 'error')
  
  return render_template('login.html')

# Update the register route to redirect to dashboard
@app.route('/register', methods=['GET', 'POST'])
def register():
  if current_user.is_authenticated:
      return redirect(url_for('dashboard'))
  
  if request.method == 'POST':
      name = request.form.get('name')
      age = request.form.get('age')
      gender = request.form.get('gender')
      username = request.form.get('username')
      password = request.form.get('password')
      confirm_password = request.form.get('confirm_password')
      
      # Validate inputs
      if not all([name, age, gender, username, password, confirm_password]):
          flash('All fields are required', 'error')
          return render_template('register.html')
      
      if password != confirm_password:
          flash('Passwords do not match', 'error')
          return render_template('register.html')
      
      # Check if username already exists
      existing_user = User.query.filter_by(username=username).first()
      if existing_user:
          flash('Username already exists', 'error')
          return render_template('register.html')
      
      # Create new user
      new_user = User(
          name=name,
          age=age,
          gender=gender,
          username=username
      )
      new_user.set_password(password)
      
      db.session.add(new_user)
      db.session.commit()
      
      flash('Registration successful! Please login.', 'success')
      return redirect(url_for('login'))
  
  return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
  logout_user()
  return redirect(url_for('login'))

# Update the profile route to include the correct back link
@app.route('/profile')
@login_required
def profile():
  return render_template('profile.html')

# Flag to track database initialization
db_initialized = False

@app.before_request
def before_request():
  global db_initialized
  if not db_initialized:
      with app.app_context():
          db.create_all()
          db_initialized = True

if __name__ == '__main__':
  with app.app_context():
      db.create_all()  # Create database tables
  app.run(debug=True)

import os
import chromadb
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
import glob

# Define the paths
pdf_folder = "pdf"  # Folder containing your 4 PDF files
embeddings_folder = "embeddings"  # Folder to store the ChromaDB database

# Create embeddings folder if it doesn't exist
os.makedirs(embeddings_folder, exist_ok=True)

# Initialize the embedding model
embedding_model = SentenceTransformer('pritamdeka/S-PubMedBert-MS-MARCO')

# Initialize ChromaDB client with persistent storage
chroma_client = chromadb.PersistentClient(path=embeddings_folder)

# Create a collection for heart disease documents
collection_name = "heart_disease_docs"

# Delete collection if it already exists (to start fresh)
try:
    chroma_client.delete_collection(collection_name)
    print(f"Deleted existing collection: {collection_name}")
except:
    print(f"No existing collection found with name: {collection_name}")

# Create a new collection
collection = chroma_client.create_collection(name=collection_name)
print(f"Created new collection: {collection_name}")

# Get all PDF files in the folder
pdf_files = glob.glob(os.path.join(pdf_folder, "*.pdf"))

if not pdf_files:
    print(f"No PDF files found in {pdf_folder}. Please add PDF files and try again.")
    exit(1)

print(f"Found {len(pdf_files)} PDF files to process.")

# Process each PDF file
total_chunks = 0
for pdf_file in pdf_files:
    file_name = os.path.basename(pdf_file)
    print(f"Processing {file_name}...")
    
    # Load the PDF
    loader = PyPDFLoader(pdf_file)
    documents = loader.load()
    
    # Split into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100
    )
    chunks = text_splitter.split_documents(documents)
    
    print(f"  - Split into {len(chunks)} chunks")
    
    # Add each chunk to the collection
    for i, doc in enumerate(chunks):
        # Create a unique ID that includes the file name
        doc_id = f"{file_name.replace('.pdf', '')}_{i}"
        
        # Generate embedding
        embedding = embedding_model.encode(doc.page_content).tolist()
        
        # Add to collection
        collection.add(
            embeddings=[embedding],
            documents=[doc.page_content],
            metadatas=[{"source": file_name, "page": doc.metadata.get("page", 0)}],
            ids=[doc_id]
        )
    
    total_chunks += len(chunks)
    print(f"  - Added to collection with IDs: {file_name.replace('.pdf', '')}_0 to {file_name.replace('.pdf', '')}_{len(chunks)-1}")

print(f"\nProcessing complete! Added {total_chunks} chunks from {len(pdf_files)} files to ChromaDB collection.")
print(f"The database is stored in the '{embeddings_folder}' folder.")
print("\nYou can now run the app.py to query this database.")